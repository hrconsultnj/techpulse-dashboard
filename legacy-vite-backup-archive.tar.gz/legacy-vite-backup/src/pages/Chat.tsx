import React from 'react'
import SynthChatInterface from '@/components/SynthChatInterface'

const Chat: React.FC = () => {
  return <SynthChatInterface />
}

export default Chat